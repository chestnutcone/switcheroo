let shift_dates = JSON.parse(document.getElementById('shift_dates').textContent)
let shift_start = JSON.parse(document.getElementById('shift_start').textContent)
let shift_end = JSON.parse(document.getElementById('shift_end').textContent)